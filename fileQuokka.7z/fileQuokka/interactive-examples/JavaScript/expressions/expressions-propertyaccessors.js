var person = {};
person['firstname'] = 'Mario';
person['lastname'] = 'Rossi';

console.log(person.firstname);
// expected output: "Mario"

person = {'firstname': 'John', 'lastname': 'Doe'}

console.log(person['lastname']);
// expected output: "Doe"