console.log(String.fromCharCode(189, 43, 190, 61));
// expected output: "½+¾="