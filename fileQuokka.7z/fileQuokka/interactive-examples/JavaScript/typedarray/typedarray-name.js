console.log(Uint8Array.name);
// expected output: "Uint8Array"

console.log(Float32Array.name);
// expected output: "Float32Array"