console.log(Float64Array.BYTES_PER_ELEMENT);
// expected output: 8

console.log(Int8Array.BYTES_PER_ELEMENT);
// expected output: 1