const uint8 = new Uint8Array([40, 10, 50, 20, 30]);
uint8.sort();

console.log(uint8);
// expected output: Uint8Array [10, 20, 30, 40, 50]