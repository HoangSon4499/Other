let uint16 = new Int16Array;
uint16 = Int16Array.of('10', '20', '30', '40' ,'50');

console.log(uint16);
// expected output: Int16Array [10, 20, 30, 40, 50]