const uint8 = new Uint8Array([1, 2, 3]);
uint8.reverse();

console.log(uint8);
// expected output: Uint8Array [3, 2, 1]