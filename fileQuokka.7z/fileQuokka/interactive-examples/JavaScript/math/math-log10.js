console.log(Math.log10(100000));
// expected output: 5

console.log(Math.log10(2));
// expected output: 0.3010299956639812

console.log(Math.log10(1));
// expected output: 0

console.log(Math.log10(0));
// expected output: -Infinity