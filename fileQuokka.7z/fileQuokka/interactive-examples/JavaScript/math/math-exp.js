console.log(Math.exp(0));
// expected output: 1

console.log(Math.exp(1));
// expected output: 2.718281828459 (approximately)

console.log(Math.exp(-1));
// expected output: 0.36787944117144233

console.log(Math.exp(2));
// expected output: 7.38905609893065