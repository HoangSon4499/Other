// 00000000000000000000000000000001
console.log(Math.clz32(1));
// expected output: 31

// 00000000000000000000000000000100
console.log(Math.clz32(4));
// expected output: 29

// 00000000000000000000001111101000
console.log(Math.clz32(1000));
// expected output: 22