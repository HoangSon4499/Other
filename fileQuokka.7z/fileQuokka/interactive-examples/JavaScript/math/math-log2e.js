function getLog2e() {
  return Math.LOG2E;
}

console.log(getLog2e());
// expected output: 1.4426950408889634