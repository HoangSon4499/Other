console.log(Math.sinh(0));
// expected output: 0

console.log(Math.sinh(1));
// expected output: 1.1752011936438014

console.log(Math.sinh(-1));
// expected output: -1.1752011936438014

console.log(Math.sinh(2));
// expected output: 3.626860407847019