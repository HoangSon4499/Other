console.log(Math.log1p(1));
// expected output: 0.6931471805599453

console.log(Math.log1p(0));
// expected output: 0

console.log(Math.log1p(-1));
// expected output: -Infinity

console.log(Math.log1p(-2));
// expected output: NaN