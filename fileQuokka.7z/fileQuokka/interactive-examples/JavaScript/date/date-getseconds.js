const moonLanding = new Date('July 20, 69 00:20:18');

console.log(moonLanding.getSeconds());
// expected output: 18