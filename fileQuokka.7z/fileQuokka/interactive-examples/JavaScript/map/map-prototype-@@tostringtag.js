var map1 = Object.prototype.toString.call(new Map());

console.log(map1);
// expected output: "[object Map]"