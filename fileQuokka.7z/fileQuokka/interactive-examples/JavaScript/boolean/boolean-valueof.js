const x = new Boolean();

console.log(x.valueOf());
// expected output: false

const y = new Boolean("Mozilla");

console.log(y.valueOf());
// expected output: true