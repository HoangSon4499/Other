var n = 0;

while (n < 3) {
  n++;
}

console.log(n);
// expected output: 3